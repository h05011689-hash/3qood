<?php

$API_KEY = "توكن";//توكن البوت
$token = $API_KEY;
$API_SU = file_get_contents("apifastpva.txt");//توكن موقع الأرقام supersms.ml
$API_APP = file_get_contents("app.txt");//توكن موقع الأرقام supersms.ml
$admin = array(1849612702,799273845,15631133662,5631133662);//ايدي المطور
$me = -1001522737969;/*
$me : 
هون بتقدر تحط الايدي تبعك
او تحط ايدي قناة
بيرسل عليها الأرقام

*/
?>




